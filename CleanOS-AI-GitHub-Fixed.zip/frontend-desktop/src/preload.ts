import { contextBridge, ipcRenderer } from 'electron';
export interface Finding {id:string;path:string;name:string;sizeBytes:number;kind:'duplicate'|'large'|'blurry'|'organizable';confidence?:number;suggestedPath?:string}
contextBridge.exposeInMainWorld('cleanos',{
 health:()=>ipcRenderer.invoke('health'),
 chooseFolder:()=>ipcRenderer.invoke('choose-folder'),
 analyze:(folder:string)=>ipcRenderer.invoke('analyze',folder),
 organize:(folder:string,ids:string[])=>ipcRenderer.invoke('organize',folder,ids),
 clean:(folder:string,ids:string[])=>ipcRenderer.invoke('clean',folder,ids),
 getModelStatus:()=>ipcRenderer.invoke('model-status')
});
