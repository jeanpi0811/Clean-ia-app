import type { Finding } from './preload';
declare global { interface Window { cleanos: {health:()=>Promise<Record<string,unknown>>;chooseFolder:()=>Promise<string|null>;analyze:(folder:string)=>Promise<Finding[]>;organize:(folder:string,ids:string[])=>Promise<{moved:number;errors:string[]}>;clean:(folder:string,ids:string[])=>Promise<{deleted:number;bytes:number}>;getModelStatus:()=>Promise<string>};} }
export {};
