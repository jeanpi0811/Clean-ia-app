# Modelos de IA

O desktop aceita um classificador ONNX de qualidade/blur via `AI_MODEL_PATH`. O pré-processamento redimensiona a imagem a 224×224, remove alpha, converte RGB para float32 NCHW e escala [0,1]. A saída é interpretada como probabilidade de blur no índice 1, com limiar 0,65. Forneça somente modelo compatível e documente licença, origem, classes e avaliação. Nenhum modelo ou dataset é redistribuído; sem arquivo compatível, a função fica indisponível. O recurso não identifica fotos semelhantes nem conteúdo semântico.
