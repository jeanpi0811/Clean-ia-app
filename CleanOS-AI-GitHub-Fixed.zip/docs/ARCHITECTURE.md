# Arquitetura CleanOS AI

## Mapa do monorepo

```text
frontend-desktop/  Electron main + preload isolado + React/Vite renderer
frontend-mobile/   React Native/Expo (iOS 15+ e Android)
backend/           NestJS REST, Prisma, autenticação, sincronização, Stripe
shared/            contratos TypeScript reutilizáveis
ai-models/         diretório de modelos ONNX provisionados pelo operador
.github/workflows/ CI de lint/typecheck/test/build
```

## Responsabilidade por dispositivo

| Recurso | Windows desktop | Android | iOS |
| --- | --- | --- | --- |
| Saúde do dispositivo | CPU/RAM/disco/sensores conforme sistema | bateria/espaço via APIs de SO | bateria/espaço via APIs de SO |
| Limpeza | apenas seleção explícita no escopo da pasta aprovada | mídia autorizada e fluxo de exclusão do SO; não limpar cache alheio | somente mídia com autorização; sem cache de outros apps |
| Fotos duplicadas | hash SHA-256 para igualdade exata | exige processamento local e APIs da biblioteca | somente assets acessíveis/selecionados |
| Blur IA | ONNX opcional, imagem 224×224 | futuro modelo mobile | futuro modelo mobile |
| Organização | prévia agrupada por extensão + mover após selecionar | futuro seletor de documentos | futuro seletor de documentos |

Detecção de apps não usados não é oferecida: Android limita dados de uso por permissão `PACKAGE_USAGE_STATS`; iOS não expõe telemetria de uso geral a apps terceiros. Temperatura e GPU dependem de sensores públicos e podem resultar em indisponibilidade.

## Segurança e fluxo
- Electron renderer não acessa Node diretamente: `contextIsolation=true`, `nodeIntegration=false`, sandbox ligado, CSP, IPC por allowlist.
- Caminhos no desktop são submetidos ao processo main; scan não segue links simbólicos nem sai da pasta escolhida. API nunca recebe o conteúdo dos arquivos.
- Backend armazena somente eventos e metadados enviados pelo app. HTTPS deve ser terminado por proxy/ingress configurado pelo operador.
- Senhas são bcrypt; access JWT curto; refresh token é rotacionado e guardado em forma hash. Use TLS, rotação de segredos e limites de taxa no proxy antes da Internet pública.
- Credenciais mobile devem residir no iOS Keychain/Android Keystore com SecureStore. Biometria é desbloqueio local (não substitui autenticação no servidor).
- Stripe valida assinatura do webhook pelo corpo bruto. Apple/Google receipt/token verification ainda deve ser conectada e testada antes de ativar benefícios premium.

## Dados
PostgreSQL guarda contas, dispositivos, eventos de limpeza, relatórios agregados, eventos de sync e referências de assinatura. Redis fornece healthcheck e lock do job semanal. Migrations estão em `backend/prisma/migrations`.

## Tarefas
Cron semanal (segunda 08:00 UTC) agrega somente eventos da semana anterior; lock Redis reduz execução concorrente. A entrega em email/push e o modo autônomo no cliente dependem de canais e autorização futuros. Nenhum daemon de limpeza opera em background.
