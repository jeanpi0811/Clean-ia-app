# Segurança e status de release

## Práticas presentes
Electron usa context isolation, preload com allowlist, sandbox e sem Node no renderer. Scans permanecem locais; caminhos são limitados à pasta selecionada; exclusão recebe somente IDs revisados, reanalisa duplicatas e ignora symlinks. Senhas têm bcrypt; refresh JWT fica armazenado como hash; tokens mobile usam SecureStore com proteção do dispositivo; Stripe webhooks conferem assinatura sobre o corpo bruto. CORS, Helmet e validação de payloads estão ativos.

## Bloqueio de publicação encontrado
No lockfile instalado durante este trabalho, `npm audit --omit=dev` reportou **33 advisories de dependências de runtime: 14 high, 1 critical, 17 moderate e 1 low**. `npm audit fix` não conseguiu resolvê-las dentro das versões declaradas; o próprio npm indicou que o caminho automático exigiria upgrades breaking de major (incluindo Expo). Não foi aplicado `--force` para não mudar versões de SDK silenciosamente. Antes de beta/produção, atualize os SDKs/workspaces em uma branch dedicada, resolva e revise cada advisory, rode os testes e revalide builds nativos. O lockfile é reproduzível, mas não é garantia de supply-chain seguro.

## Outros itens obrigatórios antes de publicar
Configurar HTTPS real e proteção de taxa no edge; secret manager e rotação de JWT/Stripe; revisão e teste de refresh/logout/recuperação; validação backend de Apple/Google billing; revisão de privacidade e exclusão de conta; backup e teste de restauração. Não há alegação de cobertura de 90% (há poucos testes smoke); não exponha a API como produto público antes de revisão profissional.
