const { PrismaClient } = require('@prisma/client');
const bcrypt = require('bcryptjs');
const prisma = new PrismaClient();
async function main() {
  const email = process.env.MASTER_EMAIL?.trim().toLowerCase();
  const password = process.env.MASTER_PASSWORD;
  if (!email || !password || password.length < 16) throw new Error('Defina MASTER_EMAIL e MASTER_PASSWORD com pelo menos 16 caracteres.');
  if (!/^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email)) throw new Error('MASTER_EMAIL inválido.');
  const passwordHash = await bcrypt.hash(password, 12);
  await prisma.user.upsert({
    where: { email },
    create: { email, passwordHash, role: 'master' },
    update: { passwordHash, role: 'master', refreshHash: null },
  });
  console.log(`Conta Master provisionada para ${email}. Nenhuma senha foi exibida.`);
}
main().catch((error) => { console.error(error.message); process.exitCode = 1; }).finally(() => prisma.$disconnect());
