import { BadRequestException, ConflictException, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import * as bcrypt from 'bcryptjs';
import { Prisma } from '@prisma/client';
import { PrismaService } from './prisma.service';

@Injectable()
export class AppService {
  constructor(private db: PrismaService, private jwt: JwtService, private config: ConfigService) {}
  async register(email: string, password: string) {
    if (password.length < 12) throw new BadRequestException('A senha deve conter pelo menos 12 caracteres.');
    const normalized = email.trim().toLowerCase();
    if (await this.db.user.findUnique({ where: { email: normalized } })) throw new ConflictException('E-mail já cadastrado.');
    const user = await this.db.user.create({ data: { email: normalized, passwordHash: await bcrypt.hash(password, 12) } });
    return this.issue(user.id, user.email, user.role);
  }
  async login(email: string, password: string) {
    const user = await this.db.user.findUnique({ where: { email: email.trim().toLowerCase() } });
    if (!user || !(await bcrypt.compare(password, user.passwordHash))) throw new UnauthorizedException('Credenciais inválidas.');
    return this.issue(user.id, user.email, user.role);
  }
  private async issue(id: string, email: string, role: string) {
    const payload = { sub: id, email, role };
    const accessToken = await this.jwt.signAsync(payload, { secret: this.config.getOrThrow('JWT_ACCESS_SECRET'), expiresIn: this.config.get('JWT_ACCESS_TTL', '15m') });
    const refreshToken = await this.jwt.signAsync({ sub: id, typ: 'refresh' }, { secret: this.config.getOrThrow('JWT_REFRESH_SECRET'), expiresIn: this.config.get('JWT_REFRESH_TTL', '30d') });
    await this.db.user.update({ where: { id }, data: { refreshHash: await bcrypt.hash(refreshToken, 12) } });
    return { accessToken, refreshToken, tokenType: 'Bearer', expiresIn: this.config.get('JWT_ACCESS_TTL', '15m') };
  }
  async refresh(token: string) {
    try {
      const claims = await this.jwt.verifyAsync<{sub:string;typ:string}>(token, { secret: this.config.getOrThrow('JWT_REFRESH_SECRET') });
      if (claims.typ !== 'refresh') throw new Error('wrong token type');
      const user = await this.db.user.findUnique({ where: { id: claims.sub } });
      if (!user?.refreshHash || !(await bcrypt.compare(token, user.refreshHash))) throw new Error('revoked');
      return this.issue(user.id, user.email, user.role);
    } catch { throw new UnauthorizedException('Refresh token inválido ou expirado.'); }
  }
  async logout(userId: string) { await this.db.user.update({ where: { id: userId }, data: { refreshHash: null } }); return { ok: true }; }
  async listDevices(userId: string) { return this.db.device.findMany({ where: { userId }, orderBy: { lastSeenAt: 'desc' } }); }
  async upsertDevice(userId: string, body: {id?:string;name:string;platform:string;metadata?:object}) {
    if (body.id) {
      const old = await this.db.device.findFirst({ where: { id: body.id, userId } });
      if (old) return this.db.device.update({ where: { id: old.id }, data: { name: body.name, platform: body.platform, metadata: body.metadata, lastSeenAt: new Date() } });
    }
    return this.db.device.create({ data: { userId, name: body.name, platform: body.platform, metadata: body.metadata } });
  }
  async addSyncEvent(userId:string, body:{deviceId:string;eventType:string;payload:Record<string,unknown>}) {
    const device = await this.db.device.findFirst({ where: { id: body.deviceId, userId } });
    if (!device) throw new BadRequestException('Dispositivo desconhecido.');
    return this.db.syncEvent.create({ data: { userId, deviceId:body.deviceId,eventType:body.eventType,payload:body.payload as Prisma.InputJsonValue } });
  }
  async getSyncEvents(userId:string, after?:string) {
    return this.db.syncEvent.findMany({ where: { userId, ...(after ? { createdAt: { gt: new Date(after) } } : {}) }, orderBy: { createdAt: 'asc' }, take: 500 });
  }
  async addCleanup(userId:string, body:{platform:string;freedBytes:string;categories:string[]}) {
    const bytes = BigInt(body.freedBytes);
    if (bytes < 0n || bytes > 9007199254740991n) throw new BadRequestException('Tamanho inválido.');
    return this.db.cleanup.create({ data: { userId, platform: body.platform, freedBytes: bytes, categories: body.categories } });
  }
  async listCleanups(userId:string) { return (await this.db.cleanup.findMany({ where: { userId }, orderBy: { createdAt:'desc' }, take:100 })).map(x=>({...x,freedBytes:x.freedBytes.toString()})); }
  async listReports(userId:string) { return this.db.weeklyReport.findMany({ where: { userId }, orderBy: { weekStart:'desc' }, take:52 }); }
  async createWeeklyReports() {
    const users = await this.db.user.findMany({ select: { id:true } });
    const now = new Date(); const weekStart = new Date(Date.UTC(now.getUTCFullYear(),now.getUTCMonth(),now.getUTCDate())); weekStart.setUTCDate(weekStart.getUTCDate()-((weekStart.getUTCDay()+6)%7));
    for (const user of users) {
      const start = new Date(weekStart); start.setUTCDate(start.getUTCDate()-7);
      const rows = await this.db.cleanup.findMany({ where: { userId:user.id, createdAt:{gte:start,lt:weekStart} } });
      const total = rows.reduce((n,r)=>n+r.freedBytes,0n).toString();
      await this.db.weeklyReport.upsert({ where:{userId_weekStart:{userId:user.id,weekStart}}, create:{userId:user.id,weekStart,payload:{cleanupCount:rows.length,freedBytes:total,generatedAt:now.toISOString()}}, update:{payload:{cleanupCount:rows.length,freedBytes:total,generatedAt:now.toISOString()}} });
    }
  }
}
