import { Module, Injectable, Logger } from '@nestjs/common';
import { randomUUID } from 'node:crypto';
import { ConfigModule, ConfigService } from '@nestjs/config';
import { JwtModule } from '@nestjs/jwt';
import { ScheduleModule, Cron } from '@nestjs/schedule';
import Redis from 'ioredis';
import { AppController } from './app.controller';
import { AppService } from './app.service';
import { JwtGuard } from './auth';
import { BillingController } from './billing.controller';
import { PrismaService } from './prisma.service';
@Injectable() class WeeklyReportJob {
 private readonly log=new Logger(WeeklyReportJob.name);
 constructor(private service:AppService,private redis:Redis){}
 @Cron('0 8 * * 1') async run(){
   const key='cleanos:weekly-report:lock';
   const token=randomUUID(); let acquired=false;
   try { const lock=await this.redis.set(key,token,'EX',300,'NX'); if(lock!=='OK')return; acquired=true; await this.service.createWeeklyReports(); }
   catch(e){this.log.error('Falha ao gerar relatórios semanais',e instanceof Error?e.stack:undefined);}
   finally { if(acquired)await this.redis.eval("if redis.call('get', KEYS[1]) == ARGV[1] then return redis.call('del', KEYS[1]) else return 0 end",1,key,token).catch(()=>undefined); }
 }
}
@Module({
 imports:[ConfigModule.forRoot({isGlobal:true}),JwtModule.register({}),ScheduleModule.forRoot()],
 controllers:[AppController,BillingController],
 providers:[PrismaService,AppService,JwtGuard,WeeklyReportJob,{provide:Redis,useFactory:(c:ConfigService)=>new Redis(c.get('REDIS_URL','redis://localhost:6379'),{lazyConnect:false,maxRetriesPerRequest:1}),inject:[ConfigService]}],
}) export class AppModule{}
