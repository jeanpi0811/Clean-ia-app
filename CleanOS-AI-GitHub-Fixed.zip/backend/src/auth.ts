import { CanActivate, ExecutionContext, Injectable, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { ConfigService } from '@nestjs/config';
import { IsEmail, IsIn, IsInt, IsObject, IsOptional, IsString, Min, MinLength, MaxLength } from 'class-validator';
import { Type } from 'class-transformer';
@Injectable()
export class JwtGuard implements CanActivate {
 constructor(private jwt:JwtService,private config:ConfigService){}
 async canActivate(ctx:ExecutionContext){
   const req=ctx.switchToHttp().getRequest(); const h=req.headers.authorization as string|undefined;
   if(!h?.startsWith('Bearer ')) throw new UnauthorizedException();
   try { const c=await this.jwt.verifyAsync(h.slice(7),{secret:this.config.getOrThrow('JWT_ACCESS_SECRET')}); req.user={id:c.sub,email:c.email}; return true; }
   catch { throw new UnauthorizedException('Token inválido ou expirado.'); }
 }
}
export class CredentialsDto { @IsEmail() email!:string; @IsString() @MinLength(12) @MaxLength(128) password!:string; }
export class RefreshDto { @IsString() refreshToken!:string; }
export class DeviceDto { @IsOptional() @IsString() id?:string; @IsString() @MaxLength(100) name!:string; @IsIn(['windows','android','ios','macos','linux']) platform!:string; @IsOptional() @IsObject() metadata?:object; }
export class SyncDto { @IsString() deviceId!:string; @IsString() @MaxLength(80) eventType!:string; @IsObject() payload!:Record<string,unknown>; }
export class CleanupDto { @IsIn(['windows','android','ios','macos','linux']) platform!:string; @IsString() freedBytes!:string; @IsString({each:true}) categories!:string[]; }
export class CheckoutDto { @IsIn(['monthly','yearly','lifetime']) plan!:string; }
