import * as SecureStore from 'expo-secure-store';
import * as LocalAuthentication from 'expo-local-authentication';
const API=process.env.EXPO_PUBLIC_API_URL;
const ACCESS='cleanos.access.v1',REFRESH='cleanos.refresh.v1';
export interface Tokens{accessToken:string;refreshToken:string;tokenType:'Bearer';expiresIn:string}
async function request<T>(route:string,init:RequestInit={},token?:string):Promise<T>{
 if(!API)throw new Error('Configure EXPO_PUBLIC_API_URL antes de usar a sincronização.');
 const base=new URL(API);if(base.protocol!=='https:'&&!['localhost','127.0.0.1'].includes(base.hostname))throw new Error('A sincronização exige HTTPS fora do dispositivo local.');
 const response=await fetch(`${API.replace(/\/$/,'')}/api${route}`,{...init,headers:{'content-type':'application/json',...(token?{authorization:`Bearer ${token}`}:{ }),...init.headers}});
 if(!response.ok){let message=`Erro ${response.status}`;try{const data=await response.json();message=data.message??message}catch{}throw new Error(Array.isArray(message)?message.join(', '):String(message));}
 return response.json() as Promise<T>;
}
export async function authenticateBiometric(){const available=await LocalAuthentication.hasHardwareAsync();if(!available)throw new Error('Este dispositivo não possui autenticação biométrica.');const enrolled=await LocalAuthentication.isEnrolledAsync();if(!enrolled)throw new Error('Configure Face ID/Touch ID/biometria nas definições do dispositivo.');const result=await LocalAuthentication.authenticateAsync({promptMessage:'Desbloquear CleanOS AI',cancelLabel:'Cancelar',disableDeviceFallback:false});if(!result.success)throw new Error('Autenticação cancelada.');}
export async function saveTokens(tokens:Tokens){await SecureStore.setItemAsync(ACCESS,tokens.accessToken,{keychainAccessible:SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,requireAuthentication:true,authenticationPrompt:'Desbloquear tokens CleanOS'});await SecureStore.setItemAsync(REFRESH,tokens.refreshToken,{keychainAccessible:SecureStore.WHEN_UNLOCKED_THIS_DEVICE_ONLY,requireAuthentication:true,authenticationPrompt:'Desbloquear tokens CleanOS'});}
export async function signIn(email:string,password:string){const tokens=await request<Tokens>('/auth/login',{method:'POST',body:JSON.stringify({email,password})});await saveTokens(tokens);return tokens;}
export async function signUp(email:string,password:string){const tokens=await request<Tokens>('/auth/register',{method:'POST',body:JSON.stringify({email,password})});await saveTokens(tokens);return tokens;}
export async function refreshAccessToken(){const refreshToken=await SecureStore.getItemAsync(REFRESH,{requireAuthentication:true,authenticationPrompt:'Renovar sessão CleanOS'});if(!refreshToken)throw new Error('Sessão não encontrada.');const tokens=await request<Tokens>('/auth/refresh',{method:'POST',body:JSON.stringify({refreshToken})});await saveTokens(tokens);return tokens.accessToken;}
export async function signOut(){const access=await SecureStore.getItemAsync(ACCESS,{requireAuthentication:true,authenticationPrompt:'Encerrar sessão CleanOS'});if(access)await request('/auth/logout',{method:'POST'},access).catch(()=>undefined);await SecureStore.deleteItemAsync(ACCESS);await SecureStore.deleteItemAsync(REFRESH);}
